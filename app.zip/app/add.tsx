import { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, Alert } from "react-native";

export default function AddTaskScreen() {
  const [task, setTask] = useState("");

  const handleAdd = () => {
    if (!task.trim()) {
      Alert.alert("Error", "Task cannot be empty");
      return;
    }
    Alert.alert("Task Added", task);
    setTask("");
  };

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center", padding: 20 }}>
      <Text style={{ fontSize: 26, fontWeight: "bold", marginBottom: 20 }}>
        Add a Task
      </Text>

      <TextInput
        placeholder="Enter your task"
        value={task}
        onChangeText={setTask}
        style={{
          width: "100%",
          borderWidth: 1,
          borderColor: "#ccc",
          borderRadius: 10,
          padding: 12,
          marginBottom: 20,
          fontSize: 16,
        }}
      />

      <TouchableOpacity
        onPress={handleAdd}
        style={{
          backgroundColor: "#e7a2e2ff",
          paddingVertical: 12,
          paddingHorizontal: 24,
          borderRadius: 10,
        }}
      >
        <Text style={{ color: "white", fontSize: 18, fontWeight: "600" }}>
          Add Task
        </Text>
      </TouchableOpacity>
    </View>
  );
}
