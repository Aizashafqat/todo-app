import { View, Text, TouchableOpacity } from 'react-native';
import { Link } from 'expo-router';

export default function AboutScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' }}>
      <Text style={{ fontSize: 26, fontWeight: 'bold', marginBottom: 20, color: '#222' }}>
        About Screen
      </Text>

      <Text style={{ fontSize: 16, color: '#555', marginBottom: 30, textAlign: 'center', paddingHorizontal: 20 }}>
         About screen using Expo Router 🚀
      </Text>

      {/* Back Button */}
      <Link href="/" asChild>
        <TouchableOpacity
          style={{
            backgroundColor: '#b84f79ff',
            paddingVertical: 12,
            paddingHorizontal: 24,
            borderRadius: 12,
          }}
        >
          <Text style={{ fontSize: 18, fontWeight: '600', color: 'white' }}>
            Back to Home
          </Text>
        </TouchableOpacity>
      </Link>
    </View>
  );
}
