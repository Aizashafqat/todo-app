import AsyncStorage from "@react-native-async-storage/async-storage";
import DateTimePicker from "@react-native-community/datetimepicker";
import React, { useEffect, useRef, useState } from "react";
import {
    Alert,
    Animated,
    FlatList,
    Share,
    StyleSheet,
    Switch,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from "react-native";
import ConfettiCannon from "react-native-confetti-cannon";

type Task = {
  id: string;
  text: string;
  completed: boolean;
  priority: "High" | "Medium" | "Low";
  dueDate?: string;
  color: string;
};

const COLORS = ["#FF9AA2", "#FFB7B2", "#FFDAC1", "#E2F0CB", "#B5EAD7", "#C7CEEA"];
const QUOTES = [
  "🌟 Keep it up!",
  "💪 You are doing great!",
  "🚀 Stay productive!",
  "🎯 Focus and conquer!",
  "✅ One step at a time!"
];

export default function IndexScreen() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [newTaskText, setNewTaskText] = useState("");
  const [darkMode, setDarkMode] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [dueDatePickerVisible, setDueDatePickerVisible] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedPriority, setSelectedPriority] = useState<Task["priority"]>("Medium");
  const [shootConfetti, setShootConfetti] = useState(false);

  const theme = darkMode
    ? {
        background: "#121212",
        text: "#ffffff",
        cardText: "#ffffff",
        input: "#1e1e1e",
        placeholder: "#aaa",
        delete: "#ff5555",
        addButton: "#6c4da0",
        quote: "#bda0ff",
      }
    : {
        background: "#fdfdfd",
        text: "#333333",
        cardText: "#000000",
        input: "#ffffff",
        placeholder: "#888888",
        delete: "#ff0055",
        addButton: "#6c4da0",
        quote: "#6c4da0",
      };

  // Load tasks from AsyncStorage
  useEffect(() => {
    (async () => {
      const stored = await AsyncStorage.getItem("@tasks");
      if (stored) setTasks(JSON.parse(stored));
    })();
  }, []);

  // Save tasks to AsyncStorage
  useEffect(() => {
    AsyncStorage.setItem("@tasks", JSON.stringify(tasks));
  }, [tasks]);

  const addTask = () => {
    if (!newTaskText.trim()) return;
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];
    const dueDateStr = selectedDate ? selectedDate.toDateString() : undefined;
    setTasks([
      ...tasks,
      {
        id: Date.now().toString(),
        text: newTaskText,
        completed: false,
        priority: selectedPriority,
        dueDate: dueDateStr,
        color,
      },
    ]);
    setNewTaskText("");
    setSelectedDate(undefined);
    setSelectedPriority("Medium");
  };

  const toggleTaskCompletion = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === id && !t.completed) {
          setShootConfetti(true); // Trigger confetti only when marking completed
        }
        return t.id === id ? { ...t, completed: !t.completed } : t;
      })
    );
  };

  const deleteTask = (id: string) => {
    Alert.alert("Delete Task", "Are you sure?", [
      { text: "Cancel" },
      { text: "Delete", style: "destructive", onPress: () => setTasks(prev => prev.filter(t => t.id !== id)) },
    ]);
  };

  const exportTasks = async () => {
    const text = tasks.map(t => `${t.text} [${t.priority}]${t.dueDate ? " Due: "+t.dueDate : ""}`).join("\n");
    try {
      await Share.share({ message: text });
    } catch (e) {
      console.log(e);
    }
  };

  const filteredTasks = tasks.filter(t => t.text.toLowerCase().includes(searchText.toLowerCase()));

  const TaskCard = ({ item }: { item: Task }) => {
    const scaleAnim = useRef(new Animated.Value(item.completed ? 1.2 : 1)).current;
    useEffect(() => {
      if (item.completed) {
        Animated.sequence([
          Animated.timing(scaleAnim, { toValue: 1.2, duration: 150, useNativeDriver: true }),
          Animated.timing(scaleAnim, { toValue: 1, duration: 150, useNativeDriver: true }),
        ]).start();
      }
    }, [item.completed]);

    return (
      <View style={[styles.taskCard, { backgroundColor: item.color }]}>
        <TouchableOpacity onPress={() => toggleTaskCompletion(item.id)}>
          <Animated.Text
            style={[
              styles.checkmark,
              { transform: [{ scale: scaleAnim }], opacity: item.completed ? 1 : 0 },
            ]}
          >
            ✅
          </Animated.Text>
        </TouchableOpacity>
        <Text
          style={[
            styles.taskText,
            { textDecorationLine: item.completed ? "line-through" : "none", color: theme.cardText },
          ]}
        >
          {item.text} {item.dueDate ? `📅 ${item.dueDate}` : ""} {item.priority === "High" ? "🔥" : item.priority === "Low" ? "💤" : ""}
        </Text>
        <TouchableOpacity onPress={() => deleteTask(item.id)}>
          <Text style={[styles.deleteButton, { color: theme.delete }]}>🗑️</Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      {/* Header */}
      <View style={styles.header}>

        {/* Switch on right */}
        <View style={{ alignItems: "center" }}>
          <Switch
            value={darkMode}
            onValueChange={setDarkMode}
            trackColor={{ false: "#ccc", true: "#6c4da0" }}
            thumbColor={darkMode ? "#fff" : "#fff"}
          />
          <Text style={{ color: theme.text, marginTop: 4, fontSize: 14 }}>
            {darkMode ? "Dark Mode" : "Light Mode"}
          </Text>
        </View>
      </View>

      {/* Motivational Quote */}
      <Text style={[styles.quote, { color: theme.quote }]}>{QUOTES[Math.floor(Math.random() * QUOTES.length)]}</Text>

      {/* Search Bar */}
      <TextInput
        placeholder="Search tasks..."
        placeholderTextColor={theme.placeholder}
        style={[styles.input, { backgroundColor: theme.input, color: theme.text, marginBottom: 15 }]}
        value={searchText}
        onChangeText={setSearchText}
      />

      {/* Add Task Input */}
      <View style={styles.addTaskContainer}>
        <TextInput
          placeholder="Add a task... 🎯"
          placeholderTextColor={theme.placeholder}
          style={[styles.input, { backgroundColor: theme.input, color: theme.text }]}
          value={newTaskText}
          onChangeText={setNewTaskText}
        />
        <TouchableOpacity style={[styles.addButton, { backgroundColor: theme.addButton }]} onPress={addTask}>
          <Text style={styles.addButtonText}>➕</Text>
        </TouchableOpacity>
      </View>

      {/* Priority Selector */}
      <View style={{ flexDirection: "row", marginBottom: 15 }}>
        {["High", "Medium", "Low"].map(p => (
          <TouchableOpacity key={p} onPress={() => setSelectedPriority(p as Task["priority"])} style={{ marginRight: 15 }}>
            <Text style={{ color: selectedPriority === p ? "#6c4da0" : theme.text, fontWeight: "bold", fontSize: 16 }}>{p}</Text>
          </TouchableOpacity>
        ))}
        <TouchableOpacity onPress={() => setDueDatePickerVisible(true)}>
          <Text style={{ marginLeft: 10, color: theme.text, fontWeight: "bold", fontSize: 16 }}>📅 Set Date</Text>
        </TouchableOpacity>
      </View>

      {dueDatePickerVisible && (
        <DateTimePicker
          value={selectedDate || new Date()}
          mode="date"
          display="default"
          onChange={(_, date) => {
            setSelectedDate(date || selectedDate);
            setDueDatePickerVisible(false);
          }}
        />
      )}

      {/* Export Button */}
      <TouchableOpacity onPress={exportTasks} style={[styles.addButton, { backgroundColor: "#ffaa00", marginBottom: 15 }]}>
        <Text style={styles.addButtonText}>📤 Export / Share</Text>
      </TouchableOpacity>

      {/* Confetti */}
      {shootConfetti && (
        <ConfettiCannon
          count={50}
          origin={{ x: -10, y: 0 }}
          fadeOut={true}
          onAnimationEnd={() => setShootConfetti(false)}
        />
      )}

      {/* Task List */}
      <FlatList
        data={filteredTasks}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <TaskCard item={item} />}
        ListEmptyComponent={<Text style={{ textAlign: "center", color: theme.placeholder, marginTop: 30 }}>No tasks yet. Add one above 👆</Text>}
        contentContainerStyle={{ paddingBottom: 100 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  header: { 
    flexDirection: "row", 
    justifyContent: "space-between", // title left, switch right
    alignItems: "center", 
    marginBottom: 20 
  },
  headerText: { fontSize: 28, fontWeight: "bold" },
  quote: { fontSize: 22, fontWeight: "600", marginBottom: 20, textAlign: "center" },
  addTaskContainer: { flexDirection: "row", marginBottom: 15 },
  input: { flex: 1, borderWidth: 1, borderRadius: 30, paddingHorizontal: 18, paddingVertical: 14, marginRight: 10, fontSize: 16 },
  addButton: { paddingHorizontal: 20, justifyContent: "center", alignItems: "center", borderRadius: 30, height: 50 },
  addButtonText: { color: "#fff", fontWeight: "bold", fontSize: 18 },
  taskCard: { flexDirection: "row", alignItems: "center", padding: 18, marginVertical: 8, borderRadius: 25, shadowColor: "#000", shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.2, shadowRadius: 4, elevation: 4 },
  taskText: { flex: 1, fontSize: 18 },
  checkmark: { fontSize: 26, marginRight: 14 },
  deleteButton: { fontSize: 22, marginLeft: 12 },
});
